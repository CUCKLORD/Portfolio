Hi!

Thank you so much for downloading the demo of Ollie! 

Please use the application launcher titled Ollie to get started!

CONTROLS:

D - Right
A - Left
W - Jump



--------------------------------------------------------------------------
LEGAL

Any and all art, music, and code belong to the RollingDice Games team. Should elements
from this game be found in unauthorized locations (online stores, merchandising, etc),
legal actin will be taken.

RollingDice Games (c)2019