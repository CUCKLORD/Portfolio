﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Gems : MonoBehaviour
{
    public GameObject manager;
    public GameObject ollie;
    public AudioSource soundSource;
    float xDiff;
    float yDiff;
   

    // Start is called before the first frame update
    void Start()
    {
        ollie = GameObject.Find("Ollie");
        soundSource = gameObject.GetComponent<AudioSource>();

    }

    // Update is called once per frame
    void Update()
    {
        // if the distance is less than or equal to one
        if (CalcDist() <= 2)
        {
            // plays the audio no matter what type of gem it is
            soundSource.Play();
            // Debug.Log("Played audio");

            // Debug.Log("Hit a gem.");
            // if and else if's to check which gem it is
            // adds to Olli'es inventory
            // deletes from manager's inventory
            // doesnt show the object anymore
            if (gameObject.GetComponent<SpriteRenderer>().sprite.name == "Gems_Air")
            {
                ollie.GetComponent<OllieMovement>().airGems.Add(new GameObject("Air Gem"));
                manager.GetComponent<GameSceneManager>().airGems.Remove(gameObject);
                gameObject.transform.position = new Vector3(0, 0, -50);
                Destroy(gameObject, soundSource.clip.length);
                // Debug.Log("Hit Air Gem.");
            }

            else if (gameObject.GetComponent<SpriteRenderer>().sprite.name == "Gems_Earth")
            {
                ollie.GetComponent<OllieMovement>().earthGems.Add(new GameObject("Earth Gem"));
                manager.GetComponent<GameSceneManager>().earthGems.Remove(gameObject);
                gameObject.transform.position = new Vector3(0, 0, -50);
                Destroy(gameObject, soundSource.clip.length);
                // Debug.Log("Hit Earth Gem.");
            }

            else if (gameObject.GetComponent<SpriteRenderer>().sprite.name == "Gems_Fire")
            {
                ollie.GetComponent<OllieMovement>().fireGems.Add(new GameObject("Fire Gem"));
                manager.GetComponent<GameSceneManager>().fireGems.Remove(gameObject);
                gameObject.transform.position = new Vector3(0, 0, -50);
                Destroy(gameObject, soundSource.clip.length);
                // Debug.Log("Hit Fire Gem.");
            }

            else if (gameObject.GetComponent<SpriteRenderer>().sprite.name == "Gems_Water")
            {
                ollie.GetComponent<OllieMovement>().waterGems.Add(new GameObject("Water Gem"));
                manager.GetComponent<GameSceneManager>().waterGems.Remove(gameObject);
                gameObject.transform.position = new Vector3(0, 0, -50);
                Destroy(gameObject, soundSource.clip.length);
                // Debug.Log("Hit Water Gem.");
            }
            else if (gameObject.GetComponent<SpriteRenderer>().sprite.name == "Key")
            {
                ollie.GetComponent<OllieMovement>().keys.Add(new GameObject("Key"));
                manager.GetComponent<GameSceneManager>().keys.Remove(gameObject);
                gameObject.transform.position = new Vector3(0, 0, -50);
                Destroy(gameObject, soundSource.clip.length);
            }
        }
    }

        /// <summary>
        /// privtae float CalcDist()
        /// returns the distance from Ollie to the game object
        /// </summary>
        /// <returns></returns>
    private float CalcDist()
    {
        return Mathf.Sqrt(Mathf.Pow((gameObject.transform.position.x - ollie.transform.position.x), 2) + Mathf.Pow((gameObject.transform.position.y - ollie.transform.position.y), 2));
        // the basic distance formula
        // sqaure root of the diff in x sqaured plus the diff in y squared

        

    }
}
