﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GUIExitButton : MonoBehaviour
{
    //Quits the Game
    public void ExitGame()
    {
        Application.Quit(100);
    }
    public void PlaySound()
    {
        gameObject.GetComponent<AudioSource>().Play();
    }
}
