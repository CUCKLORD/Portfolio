﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Chest : MonoBehaviour
{
    public GameObject manager;
    public GameObject ollie;
    public AudioSource soundSource;
    public Animator anim;

    // Start is called before the first frame update
    void Start()
    {
        ollie = GameObject.Find("Ollie");
    }

    // Update is called once per frame
    void Update()
    {
        if (CalcDist() <= 2f && ollie.GetComponent<OllieMovement>().hasKey == true && soundSource.isPlaying == false)
        {
            soundSource.Play();
            anim.SetBool("Open", true);
            manager.GetComponent<GameSceneManager>().openChests = true;
        }
    }

    // gets the distance from Ollie to the object
    private float CalcDist()
    {
        return Mathf.Sqrt(Mathf.Pow((gameObject.transform.position.x - ollie.transform.position.x), 2) + Mathf.Pow((gameObject.transform.position.y - ollie.transform.position.y), 2));
        // the basic distance formula
        // sqaure root of the diff in x sqaured plus the diff in y squared
    }
}
