﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OllieMovement : MonoBehaviour
{
    //int for allowing Ollie to Jump, and a Vector2 for manipulating his position
    public Vector2 hVelocity;
    public Vector2 acceleration;
    public float friction;
    public Vector2 position;
    public Rigidbody2D ollieBody;
    public float MaxSpeed;
    bool ableToJump;

    // camera
    public Camera ollieCam;

    // animator
    public Animator anim;

    // audio stuff
    public AudioSource moveSound;
    public AudioSource jumpSound;

    // inventory system
    public List<GameObject> airGems;
    public List<GameObject> earthGems;
    public List<GameObject> fireGems;
    public List<GameObject> waterGems;
    public List<GameObject> keys;

    // bool for carrying key
    public bool hasKey;

    // bool for facing 
    public bool facingRight;
    

    //When buttons are pressed, acceleration should be added to velocity in that direction
    //Every frame, add the velocity to the position
    //When the button is let go, apply negative acceleration to velocity * coefficient of friction

    //Make sure to clamp velocity every frame

    // Start is called before the first frame update
    void Start()
    {
        hVelocity = new Vector2(0, 0);
        //vVelocity = new Vector2(0, 0.1f);
        acceleration = new Vector2(0.01f, 0);
        friction = 0.75f;
        MaxSpeed = 0.1f;
        position = gameObject.transform.position;
        ollieCam.transform.position = new Vector3(position.x, position.y, -2);
        ollieBody = gameObject.GetComponent<Rigidbody2D>();
        ollieBody.velocity = new Vector2(0, -0.01f);
        hasKey = false;
        facingRight = true;
    }

    // Update is called once per frame
    void Update()
    {

        position += ollieBody.velocity; // adds the rigidbody's physics to Ollie

        // if statements for movements
        if (Input.GetKey(KeyCode.D))//  || Input.GetKey(KeyCode.RightArrow))
        {
            hVelocity += acceleration;

            hVelocity = Vector2.ClampMagnitude(hVelocity, MaxSpeed);

            position += hVelocity;

            anim.SetFloat("SpeedF", 1);

            if (ableToJump)
            {
                gameObject.GetComponent<SpriteRenderer>().flipX = false;
            }
            else
            {
                gameObject.GetComponent<SpriteRenderer>().flipX = true;
            }

            facingRight = true;


            if (moveSound.isPlaying == false)
            {
                moveSound.Play();
            }
        }

        else if (Input.GetKey(KeyCode.A))//  || Input.GetKey(KeyCode.LeftArrow))
        {
            hVelocity += -(acceleration);

            hVelocity = Vector2.ClampMagnitude(hVelocity, MaxSpeed);

            position += hVelocity;

            anim.SetFloat("SpeedF", 1);

            if (ableToJump)
            {
                gameObject.GetComponent<SpriteRenderer>().flipX = true;
            }
            else
            {
                gameObject.GetComponent<SpriteRenderer>().flipX = false;
            }

            facingRight = false;

            if (moveSound.isPlaying == false)
            {
                moveSound.Play();
            }
        }

        else // if no key is pressed Ollie slows down
        {
            hVelocity *= friction;
            position += hVelocity;

            if (Mathf.Abs(hVelocity.magnitude) <= 0.01)
            {
                hVelocity.x = 0;
                hVelocity.y = 0;
            }

            anim.SetFloat("SpeedF", 0);

            moveSound.Stop();
            if(facingRight)
            {
                gameObject.GetComponent<SpriteRenderer>().flipX = true;
            }
            else
            {
                gameObject.GetComponent<SpriteRenderer>().flipX = false;
            }
        }

        // if for jumping of Ollie
        if (Input.GetKeyDown(KeyCode.W) && ableToJump == true)
        {
            hVelocity += new Vector2(0, 1.2f);

            // hVelocity = Vector2.ClampMagnitude(hVelocity, MaxSpeed);

            position += hVelocity;
            ableToJump = false;

            anim.SetBool("Jumping", true);

            jumpSound.Play();
        }

        // makes sure if Ollie falls all the way down, he comes back up again.
        if (position.y <= -30f)
        {
            position.y = 7.5f;
            position.x = -41f;
        }

        // if statements that makes sure Ollie stays on screen    -41    45
        if(position.x <= -41)
        {
            position.x = -40.9f;
        }

        if(position.x >= 45)
        {
            position.x = 44.9f;
        }
        // sets the position of the object in the game
        gameObject.transform.position = position;
        
        // sets up the cam position
        ollieCam.transform.position = new Vector3(position.x, position.y, -2);
        


    }

    // method that makes sure Ollie can only jump when he is touching a 2d box collider
    private void OnCollisionEnter2D(Collision2D collision)
    {
        ableToJump = true;
        anim.SetBool("Jumping", false);
        
    }

}
