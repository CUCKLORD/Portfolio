﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

[RequireComponent(typeof(Button))]
public class GUIStartButton : MonoBehaviour
{
    //Transitions to Sample Scene
   

    public void StartGame(string sceneName)
    {
        SceneManager.LoadScene(sceneName);
        
    }
    public void PlaySound()
    {
        gameObject.GetComponent<AudioSource>().Play();
    }
}
