﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MupBup : MonoBehaviour
{
    public GameObject manager;
    public GameObject ollie;
    public AudioSource soundSource;
    public Animator anim;
    public GameObject lunPrefab;
    public GameObject newLun;
    WaitForSeconds animWait;
    public bool transformed;
    public GameObject instructions;

    // Start is called before the first frame update
    void Start()
    {
        ollie = GameObject.Find("Ollie");


        newLun = Instantiate<GameObject>(lunPrefab, gameObject.transform.position, Quaternion.identity);
        newLun.GetComponent<SpriteRenderer>().sortingLayerName = "Default";
        instructions.GetComponent<SpriteRenderer>().sortingLayerName = "Default";
    }

    // Update is called once per frame
    void Update()
    {
        if(CalcDist() <= 4 && !transformed)
        {
            instructions.GetComponent<SpriteRenderer>().sortingLayerName = "Middle";
        }
        else
        {
            instructions.GetComponent<SpriteRenderer>().sortingLayerName = "Default";
        }
    }

    // gets the distance from Ollie to the object
    private float CalcDist()
    {
        return Mathf.Sqrt(Mathf.Pow((gameObject.transform.position.x - ollie.transform.position.x), 2) + Mathf.Pow((gameObject.transform.position.y - ollie.transform.position.y), 2));
        // the basic distance formula
        // sqaure root of the diff in x sqaured plus the diff in y squared
    }

    public void Transform()
    {
        soundSource.Play();
        anim.SetBool("Transform", true);
        animWait = new WaitForSeconds(2);
        newLun.GetComponent<SpriteRenderer>().sortingLayerName = "Middle";
        gameObject.GetComponent<SpriteRenderer>().sortingLayerName = "Default";
        transformed = true;
        //manager.GetComponent<GameSceneManager>().mupbups.Remove(gameObject);
        //Destroy(gameObject, soundSource.clip.length);
    }
}
