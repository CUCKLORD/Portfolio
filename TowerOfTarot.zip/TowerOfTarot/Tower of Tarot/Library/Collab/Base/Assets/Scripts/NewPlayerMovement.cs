﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NewPlayerMovement : MonoBehaviour
{
    // variables
    public Vector3 velocity;
    public float xVel;
    public float yVel;
    public float yAcceleration;
    public Animator animate;
    public bool isJumping;
    public float gravConstant;
    public float jumpConstant;
    public float speed;
    public float friction;

    public Vector3 prevPosition;
    public Vector3 charPosition;
    public Vector3 max;
    public Vector3 min;
    public List<BoxCollider2D> collisions;

    private RaycastHit2D prevHit;

    public enum enChaos { HalfGrav, GravFlip, VecSwitch, Slippery, HotKeySwitch, Sticky };

    public static enChaos enumState;


    public string enumString;


    // Start is called before the first frame update
    void Start()
    {
        collisions = new List<BoxCollider2D>();
        charPosition = transform.position;
        prevPosition = charPosition;
        // sets values for x and y velocity
        xVel = 0.0f;
        yVel = 0.0f;

        // mkes the velocity vector with the x and y velocity
        velocity = new Vector3(xVel, yVel);

        // sects y acceleration
        yAcceleration = 0.0f;

        isJumping = true;

        // sets default grav constant
        gravConstant = -0.01f;

        // sets default jump constant
        jumpConstant = 0.13f;

        // sets default speed
        speed = 0.1f;

        // sets default friction
        friction = 0.01f;

        enumString = enumState.ToString();
        Debug.Log(enumString);

        if (enumState == enChaos.HalfGrav)
        {
            // Halve gravity constant
        }

        if (enumState == enChaos.GravFlip)
        {
            // negate gravity constant
        }

        if (enumState == enChaos.VecSwitch)
        {
            // Switch vecctors
        }

        if (enumState == enChaos.Slippery)
        {
            friction = 0.005f;
            Debug.Log("Slippery");
        }

        if (enumState == enChaos.HotKeySwitch)
        {
            // Alter hotkeys using random
        }

        if (enumState == enChaos.Sticky)
        {
            // if(IsGrounded())
            // {
            //     speed = .075f;
            // }
            friction = 0.05f;
            Debug.Log("Got Sticky");
        }

        animate = gameObject.GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        if(enumState == enChaos.Sticky)
        {
            if(IsGrounded())
            {
                speed = 0.04f;
            }
            else
            {
                speed = 0.1f;
            }
        }
        //if (!isJumping)
        //{

        if (isJumping = IsGrounded())
        {

            // if the player jumps, calls jump. if not, call fall
            if (Input.GetKeyDown(KeyCode.Space))
            {
                Jump();
            }
        }
        //}
        else
        {
            isJumping = true;
            Fall();
        }


        // if the player hits d, move right, if the player hits a, move left, otherwise, stop
        if (Input.GetKey(KeyCode.D))
        {
            MoveRight();
            // animate.SetBool("Mirrored", false);
            gameObject.GetComponent<SpriteRenderer>().flipX = false;


        }
        else if (Input.GetKey(KeyCode.A))
        {
            MoveLeft();
            // animate.SetBool("Mirrored", true);
            gameObject.GetComponent<SpriteRenderer>().flipX = true;
        }
        else if (xVel != 0.0f)
        {
            Decelerate();
        }
        else
        {
            // animate.Play("Idle");
        }

        // set x component of velocity 
        velocity.x = xVel;

        // set speed for animator
        animate.SetFloat("Speed", Mathf.Abs(xVel));

        // add y accel to y velocity
        yVel += yAcceleration;

        // clapm yvelocity
        //yVel = Mathf.Max(yVel, gravConstant);  // might need to min if we change gravity to positive

        // set y component of velocity
        velocity.y = yVel;

        charPosition += velocity;

        NewCollision();

        // update position
        gameObject.transform.position = charPosition;

        prevPosition = charPosition;
    }

    /// <summary>
    /// Checks if there is ground beneath the character or not (if he should fall)
    /// </summary>
    public bool IsGrounded()
    {
        // Bitshifts layerMask so that it's the 9th layer
        int layerMask = 1 << 9;

        // Not it so that this ray will collide with everything BUT the character layer
        layerMask = ~layerMask;

        BoxCollider2D playerBox = gameObject.GetComponent<BoxCollider2D>();
        float dist = playerBox.bounds.extents.y + .1f;
        max = new Vector3(transform.position.x + playerBox.bounds.extents.x, transform.position.y, transform.position.z);
        min = new Vector3(transform.position.x - playerBox.bounds.extents.x, transform.position.y, transform.position.z);
        // Debug.Log("Yote");
        // Performs 2 raycasts from the min and the max of the character's extents.  If BOTH of them hit something, then fall
        if (!(Physics2D.Raycast(min, Vector2.down, dist, layerMask)) &&
            !(Physics2D.Raycast(max, Vector2.down, dist, layerMask)) &&
            !(Physics2D.Raycast(transform.position, Vector2.down, dist, layerMask))
            )
        {
            Debug.Log("Yeet");
            // isJumping = true;
            return false;
        }
        return true;

    }
    // adds to the xvelocity to have the player move right
    public void MoveRight()
    {
        // if th velocity isnt full right, add to it a
        if (xVel < speed)
        {
            xVel += friction;
        }

        // clamps x vel
        else
        {
            xVel = speed;
        }

    }


    // suntracts from the xvelocity to move left
    public void MoveLeft()
    {

        // if the x vel isnt full left, subtract from it
        if (xVel > -speed)
        {
            xVel -= friction;
        }

        // clamp the x vel
        else
        {
            xVel = -speed;
        }

    }


    // adds to the yvelocity to jump
    public void Jump()
    {
        // if(yVel < 1.0f)
        // {
        //     yVel += 0.1f;
        // }
        // else
        // {
        //     yVel = 1.0f;
        // }

        // yVel += 1.0f;


        // while(yVel < 1.0f)
        // {
        //     yVel += 0.01f;
        // }
        // yAcceleration = 0.0f;

        // add to y accel
        //if (yVel == 0)
        //{
        yVel += jumpConstant;
        //}
        // isJumping = true;
    }


    // decelerate the character if no button is pressed
    public void Decelerate()
    {
        // if you are going right, start to subtrat from x vel
        if (xVel > 0.0f)
        {
            xVel -= 0.75f * friction;
        }

        // if youre going left add to x vel
        else if (xVel < 0.0f)
        {
            xVel +=  0.75f * friction;
        }

        if (xVel <= 0.005f && xVel >= -0.005f)
        {
            xVel = 0.0f;
        }
    }


    // falls when space isnt pressed
    public void Fall()
    {
        // while(yVel > 0.0f)
        // {
        //     yVel -= 0.1f;
        // }
        // 
        // if(yVel < 0.0f)
        // {
        //     yVel = 0.0f;
        // }
        Debug.Log("Falling");
        yVel += gravConstant;
        // ObjectBelow();

    }

    private void ObjectBelow()
    {
        // Bitshifts layerMask so that it's the 9th layer
        int layerMask = 1 << 9;

        // Not it so that this ray will collide with everything BUT the character layer
        layerMask = ~layerMask;
        RaycastHit2D thisHit;
        BoxCollider2D playerBox = gameObject.GetComponent<BoxCollider2D>();
        float dist = playerBox.bounds.extents.y + .1f;
        // Debug.Log("Yote");
        // Performs 2 raycasts from the min and the max of the character's extents.  If BOTH of them hit something, then fall
        if ((thisHit = Physics2D.Raycast(transform.position, Vector2.down, 100.0f, layerMask))
            )
        {
            if (prevHit == false)
                prevHit = thisHit;
            Debug.Log("Prev hit: " + prevHit.transform.position);
            Debug.Log("This hit: " + thisHit.transform.position);
            if (thisHit != prevHit)
            {
                Debug.Log("fallThrough");
                charPosition = Vector3.zero;
            }
        }

        prevHit = thisHit;
    }

    /*
    public void OnTriggerEnter2D(Collider2D collision)
    {
        Debug.Log("Yote");
        Debug.Log(isJumping);
        BoxCollider2D boxBoi = gameObject.GetComponent<BoxCollider2D>();
        Vector3 tempPosition = prevPosition;
        // Vector3 tempPosition = charPosition;
        if (collision.tag == "Vertical")
        {
            Debug.Log("Poggers?");

            float temp1 = (collision.bounds.extents.x + gameObject.GetComponent<BoxCollider2D>().bounds.extents.x);
            //-Mathf.Abs(charPosition.x - collision.transform.position.x);
            if (xVel < 0)
                tempPosition.x = temp1 + collision.transform.position.x + .04f;
            else
                tempPosition.x = collision.transform.position.x - (temp1 + .04f);

            xVel = 0;

        }
        else
        //if (collision.tag == "Platform")
        {
            float temp = (collision.bounds.extents.y + boxBoi.bounds.extents.y);
            float temp1 = (collision.bounds.extents.x + boxBoi.bounds.extents.x);
            //- Mathf.Abs(prevPosition.y - collision.transform.position.y);
            // if ((prevPosition.y - collision.transform.position.y) > 0)
            //     charPosition.y += temp;
            // else
            //     charPosition.y -= temp;
            if (tempPosition.x - boxBoi.bounds.extents.y < collision.transform.position.x - collision.bounds.extents.x && xVel > 0)
            {
                tempPosition.x = collision.transform.position.x - (temp1 + .04f);

                xVel = 0;
            }
            else if (tempPosition.x + boxBoi.bounds.extents.y > collision.transform.position.x + collision.bounds.extents.x)
            {

                tempPosition.x = temp1 + collision.transform.position.x + .04f;
                xVel = 0;
            }
            // else if(tempPosition.x < collision.transform.position.x 
            //     && tempPosition.x > collision.transform.position.x - collision.bounds.extents.x 
            //     && tempPosition.y > collision.transform.position.y - collision.bounds.extents.y 
            //     &&tempPosition.y < collision.transform.position.y + collision.bounds.extents.y
            //     )
            // {
            //     Debug.Log("This should be the edge case!");
            // }
            else
            {
                if (yVel < 0)
                {
                    tempPosition.y = temp + collision.transform.position.y + .03f;
                }
                else
                {
                    tempPosition.y = collision.transform.position.y - (temp + .03f);
                }
            }


            yVel = 0;
            yAcceleration = 0;
        }
        charPosition = tempPosition;
        // charPosition = prevPosition;
        // transform.position = prevPosition;
        transform.position = charPosition;
    }
    */

    public void NewCollision()
    {
        collisions.Clear();
        float minX;
        float maxX;
        float minY;
        float maxY;
        bool check1;
        bool check2;
        bool check3;
        bool check4;
        BoxCollider2D playerBox = gameObject.GetComponent<BoxCollider2D>();
        // Debug.Log(PlatformBoxColliderSet.platforms.Count);
        foreach (BoxCollider2D test in PlatformBoxColliderSet.platforms)
        {
            // Figures out which of the platforms are close
            if (Mathf.Abs(test.transform.position.y - (charPosition.y)) - test.bounds.extents.y < .5f
                && Mathf.Abs(test.transform.position.x - (charPosition.x)) - test.bounds.extents.x < .5f
                )
            {
                // Debug.Log("Platform: " + test.name + " Is either less than .5 vertical or horizontal units from player");
                collisions.Add(test);
            }
        }
        if (collisions.Count > 0)
        {

            minX = charPosition.x - playerBox.bounds.extents.x;
            maxX = charPosition.x + playerBox.bounds.extents.x;
            minY = charPosition.y - playerBox.bounds.extents.y;
            maxY = charPosition.y + playerBox.bounds.extents.y;
            foreach (BoxCollider2D plat in collisions)
            {
                check1 = minX < plat.bounds.max.x;
                check2 = minY < plat.bounds.max.y;
                check3 = maxX > plat.bounds.min.x;
                check4 = maxY > plat.bounds.min.y;
                if (check1 &&
                    check2 &&
                    check3 &&
                    check4)
                {
                    // Debug.Log("Colliding with: " + plat.name);
                    // If unit is colliding on let or right, and no other axis
                    // This if statement checks the previous position and chekcs if all but 3 are true.  If both x checks are
                    // false or both are tru, this will
                    if ((!(prevPosition.x - playerBox.bounds.extents.x < plat.bounds.max.x) 
                        || !(prevPosition.x + playerBox.bounds.extents.x > plat.bounds.min.x)) 
                        && check2 && check4)
                    {
                        Debug.Log("Uhhhhh");
                        // prevPosition.x += (prevPosition.x - plat.transform.position.x) - 
                        //     (playerBox.bounds.extents.x + plat.bounds.extents.x);

                        prevPosition.y = charPosition.y;
                    }
                    else
                    {
                    //if (yVel < 0)
                    //{
                        yAcceleration = 0;
                        yVel = 0;
                    //}
                    //else
                    //{
                    //}
                    }
                    
                    charPosition = prevPosition;
                    isJumping = false;
                    break;
                }
            }
        }

    }
}
