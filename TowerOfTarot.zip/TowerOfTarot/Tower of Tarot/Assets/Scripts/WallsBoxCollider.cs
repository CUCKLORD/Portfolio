﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WallsBoxCollider : MonoBehaviour
{
    //variables 
    public Vector2 boxColliderSize;
    public BoxCollider2D boxCollider;
    // Start is called before the first frame update
    void Start()
    {
        //create size of box collider
        boxColliderSize = new Vector2(3, transform.localScale.y * 2);
        boxCollider = gameObject.GetComponent<BoxCollider2D>();
        boxCollider.size = boxColliderSize;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
