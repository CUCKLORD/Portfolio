﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class KnifeTime : MonoBehaviour
{
    //variables
    public float rateOfAcceleration;
    public float maxSpeed;
    public Vector3 knifePosition;
    public Vector3 direction = new Vector3(0, -1, 0);
    public Vector3 velocity = Vector3.zero;
    public Vector3 acceleration = Vector3.zero;
    public GameObject cam;
    public float camWidth;
    public float camHeight;
    //collision variable 
    public bool collision = false;
    public GameObject fool;

    public GameObject warningPrefab;
    public GameObject warningForThis;

    // Start is called before the first frame update
    void Start()
    {
        fool = GameObject.Find("TesterBoi");
        //instantiate the size of the camera
        cam = GameObject.Find("Main Camera");
        camHeight = cam.GetComponent<Camera>().orthographicSize;
        camWidth = camHeight * cam.GetComponent<Camera>().aspect;

        //assign knife position
        knifePosition = gameObject.transform.position;

        rateOfAcceleration = 1f;

        maxSpeed = 0.05f;

        SpawnWarning();
    }

    // Update is called once per frame
    void Update()
    {
        //move the knife
        Move();

        //check for collisions
        collision = false;

        //check if the knife is hitting the player
        if(CollisionCircular(gameObject, fool))
        {
            collision = true;
        }
        //if colliding, reset the level
        if(collision == true)
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        }

        if(gameObject.transform.position.y <= -5)
        {
            GameObject.Destroy(gameObject);
        }

        KillWarning();
    }

    public void Move()
    {
        //find acceleration
        acceleration = direction * rateOfAcceleration;

        //add acceleration to velocity
        velocity += acceleration;

        //limit velocity with clamp
        velocity = Vector3.ClampMagnitude(velocity, maxSpeed);

        //add velocity to vehicle position
        knifePosition += velocity;

        gameObject.transform.position = knifePosition;
        //check if 
    }

    //collisions 
    public bool CollisionCircular(GameObject a, GameObject b)
    {
        //return variable
        bool colliding;

        //find the radius of the circular bounds 
        //a's radius
        float aRadius = Mathf.Pow(a.GetComponent<SpriteRenderer>().bounds.max.y - a.GetComponent<SpriteRenderer>().bounds.center.y, 2) +
            Mathf.Pow(a.GetComponent<SpriteRenderer>().bounds.max.x - a.GetComponent<SpriteRenderer>().bounds.center.x, 2);
        //b's radius
        float bRadius = Mathf.Pow(b.GetComponent<SpriteRenderer>().bounds.max.y - b.GetComponent<SpriteRenderer>().bounds.center.y, 2) +
            Mathf.Pow(b.GetComponent<SpriteRenderer>().bounds.max.x - b.GetComponent<SpriteRenderer>().bounds.center.x, 2);
        //distance between the two objects centers
        float distanceSqr = (Mathf.Pow(a.GetComponent<SpriteRenderer>().bounds.center.x - b.GetComponent<SpriteRenderer>().bounds.center.x, 2) +
            Mathf.Pow(a.GetComponent<SpriteRenderer>().bounds.center.y - b.GetComponent<SpriteRenderer>().bounds.center.y, 2));

        //check for the collision
        if ((aRadius + bRadius) > distanceSqr)
        {
            colliding = true;
        }
        else
        {
            colliding = false;
        }

        //return bool 
        return colliding;
    }

    public void SpawnWarning()
    {
        warningForThis = GameObject.Instantiate(warningPrefab, new Vector3(gameObject.transform.position.x, 4.8f, 0), Quaternion.identity);
    }

    public void KillWarning()
    {
        if(warningForThis != null && gameObject.transform.position.y <= warningForThis.transform.position.y)
        {
            GameObject.Destroy(warningForThis);
        }
    }
}
