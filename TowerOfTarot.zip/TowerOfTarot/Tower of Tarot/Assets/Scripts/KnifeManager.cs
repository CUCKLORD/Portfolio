﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KnifeManager : MonoBehaviour
{
    //variables 
    public List<GameObject> knifes;
    public GameObject fool;
    public float timeForNewKnife;
    public Camera cam;
    public float camWidth;
    public float camHeight;
    // Start is called before the first frame update
    void Start()
    {
        //instantiate the size of the camera
        camHeight = cam.GetComponent<Camera>().orthographicSize;
        camWidth = camHeight * cam.GetComponent<Camera>().aspect;

        //instatiate the list
        knifes = new List<GameObject>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
