﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlatformBoxColliderSet : MonoBehaviour
{
    //variables 
    public SpriteRenderer spriteRenderer;
    public Sprite sprite;
    public Vector2 boxColliderSize;
    public BoxCollider2D boxCollider;
    // public string enumString;
    // public Renderer m_renderer;

    public static List<BoxCollider2D> platforms;
    private void Awake()
    {
        platforms = new List<BoxCollider2D>();
    }
    // Start is called before the first frame update
    void Start()
    {
        spriteRenderer = gameObject.GetComponent<SpriteRenderer>();
        sprite = spriteRenderer.sprite;
        boxColliderSize = new Vector2(spriteRenderer.size.x, spriteRenderer.size.y);
        boxCollider = gameObject.GetComponent<BoxCollider2D>();
        boxCollider.size = boxColliderSize;
        platforms.Add(boxCollider);
        // m_renderer = gameObject.GetComponent<Renderer>();

        // if (NewPlayerMovement.enumState == NewPlayerMovement.enChaos.LavaFloor)
        // {
        //     m_renderer.material.color = new Color(250, 118, 98);
        //     m_renderer.material.GetInt
        //     // spriteRenderer.color = new Color(250, 118, 98, 255);
        //     Debug.Log("Made it red");
        // }
        // enumString = NewPlayerMovement.enumState.ToString();
        // Debug.Log("r:" + spriteRenderer.color.r + " g:" + spriteRenderer.color.g + " b:" + spriteRenderer.color.b);
    }

    // Update is called once per frame
    void Update()
    {
        // if(NewPlayerMovement.enumState == NewPlayerMovement.enChaos.LavaFloor)
        // {
        //     if (spriteRenderer.color.r < 254)
        //     {
        //         spriteRenderer.color = new Color(spriteRenderer.color.r + 1, 118, 98);
        //     }
        //     else if (gameObject.GetComponent<SpriteRenderer>().color.r > 245)
        //     {
        //         spriteRenderer.color = new Color(spriteRenderer.color.r - 1, 118, 98); ;
        //     }
        // }
        // Debug.Log("r:" + spriteRenderer.color.r + " g:" + spriteRenderer.color.g + " b:" + spriteRenderer.color.b);
    }
}
