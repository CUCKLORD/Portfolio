﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using System;

public class ChaosManager : MonoBehaviour
{

    public GameObject foolObject;
    public NewPlayerMovement foolScript;
    public string[] scenes;
    public int currentScene;

    public GameObject swordPrefab;

    public float timer;
    public float deltaSwordTime;

    public System.Random rng;

    // Start is called before the first frame update
    void Start()
    {
        rng = new System.Random();
        // creates the scenes
       scenes = new string[] { "IntroStage", "SlipperyStage", "StickyStage" , "KeyMapStage", "LavaFloorStage", "Infinite", "EndScreen"};

        // sets current scene
       currentScene = Array.IndexOf(scenes, SceneManager.GetActiveScene().name);
       // Debug.Log(currentScene);

        // finds the script
       // foolScript = foolObject.GetComponent<NewPlayerMovement>();
       
        // switch for which scene we are in.
       switch (currentScene)
       {
           case 0:
                NewPlayerMovement.enumState = NewPlayerMovement.enChaos.Intro; // PlayerMovement.enChaos.Slippery;
           break;
           case 1:
               NewPlayerMovement.enumState = NewPlayerMovement.enChaos.Slippery;
               break;
           case 2:
               NewPlayerMovement.enumState = NewPlayerMovement.enChaos.Sticky;
               break;
            case 3:
                NewPlayerMovement.enumState = NewPlayerMovement.enChaos.HotKeySwitch;
                break;
            case 4:
                NewPlayerMovement.enumState = NewPlayerMovement.enChaos.LavaFloor;
                break;
            case 5:
                NewPlayerMovement.enumState = NewPlayerMovement.enChaos.Infinite;
                break;
            case 6:
                NewPlayerMovement.enumState = NewPlayerMovement.enChaos.Intro;
                break;
            default:
       
               break;
       }

        // sets up timers for swords
        deltaSwordTime = 3.0f;
        timer = 0.0f * Time.deltaTime;
    }

    // Update is called once per frame
    void Update()
    {
        // deltaSwordTime = 90.0f * Time.deltaTime;
        // increments sword timer
        timer += Time.deltaTime;

        // if timer is higher than delta timer, spawn a sword
        if (timer >= deltaSwordTime)
        {
            timer = 0.0f * Time.deltaTime;
            SpawnSword();
        }


        // hit r to reset. for testing purposes
        if (Input.GetKeyDown(KeyCode.R))
        {
            SceneManager.LoadScene(scenes[currentScene]);
        }

        // hit n for next stage. for testing purposes
        if (Input.GetKeyDown(KeyCode.N))
        {
            FinishLevel();
        }

        // hit esc to go to menu
        if(Input.GetKeyDown(KeyCode.Escape))
        {
            SceneManager.LoadScene("Menu");
        }
    }

    /// <summary>
    /// FinishLevel()
    /// Adds to the scene counter and loads the scene from the array. If you are at the end, loops back to the start
    /// </summary>
    public void FinishLevel()
    {
        if (currentScene < scenes.Length - 1)
        {
            currentScene += 1;
            SceneManager.LoadScene(scenes[currentScene]);
        }
        else if(currentScene == scenes.Length - 1)
        {
            currentScene = 0;
            SceneManager.LoadScene(scenes[currentScene]);
        }
    }


    /// <summary>
    /// Checks if the object this is attached to hits the player. if true, call FinishLevel()
    /// </summary>
    /// <param name="collider"></param>
    public void OnTriggerEnter2D(Collider2D collider)
    {
        if(collider.gameObject == foolObject)
        {
            FinishLevel();
        }
    }

    /// <summary>
    /// SpawnSword()
    /// spawns a sword at a random x position within the bounds and at a set y position
    /// </summary>
    public void SpawnSword()
    {
        GameObject.Instantiate(swordPrefab, new Vector3(rng.Next(-3, 4), CameraMove.GetTopY() + 2, 0), Quaternion.identity);
    }
}
