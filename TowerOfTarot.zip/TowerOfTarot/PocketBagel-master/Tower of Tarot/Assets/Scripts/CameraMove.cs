﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraMove : MonoBehaviour
{
    public Camera cam;
    public static Camera staticCam;
    public static float width;
    public static float height;
       
    // Start is called before the first frame update
    void Start()
    {
        staticCam = cam;
        height = staticCam.orthographicSize;
        width = height * staticCam.aspect;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public static void MoveCamera(float amount)
    {
        Vector3 temp = staticCam.transform.position;
        temp.y += amount;
        staticCam.transform.position = temp;
    }

    public static float GetTopY()
    {
        return staticCam.transform.position.y + height;
    }

    public static float GetBotY()
    {
        return staticCam.transform.position.y - height;
    }
}
