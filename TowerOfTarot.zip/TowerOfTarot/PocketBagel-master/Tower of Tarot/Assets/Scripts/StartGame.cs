﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using System;

public class StartGame : MonoBehaviour
{
    //VARIABLES 
    public string[] scenes;
    public int currentScene;
    public SpriteRenderer startButton;

    // Start is called before the first frame update
    void Start()
    {
        //scenes = new string[] { "Menu", "IntroStage" };
        currentScene = Array.IndexOf(scenes, SceneManager.GetActiveScene().name);
        
    }
       

    // Update is called once per frame
    void Update()
    {
        if (Input.mousePosition.x > (startButton.transform.position.x - ((startButton.size.x * startButton.transform.localScale.x) / 2)) && 
            Input.mousePosition.x < (startButton.transform.position.x + ((startButton.size.x * startButton.transform.localScale.x) / 2)) &&
            Input.mousePosition.y > (startButton.transform.position.y - ((startButton.size.y * startButton.transform.localScale.y) / 2)) && 
            Input.mousePosition.y > (startButton.transform.position.y + ((startButton.size.y * startButton.transform.localScale.y) / 2)))
        {
            Debug.Log("On Top of Button");
            if (Input.GetMouseButtonDown(0))
            {
                FinishLevel();
                Debug.Log("Button Pressed");
            }
        }

        if (Input.GetKeyDown(KeyCode.Return))
        {
            FinishLevel();
        }
        else if(Input.GetKeyDown(KeyCode.Escape))
        {
            Debug.Log("Hit Escape");
            Application.Quit();
        }
    }

    public void FinishLevel()
    {
        if (currentScene < scenes.Length - 1)
        {
            currentScene += 1;
            SceneManager.LoadScene(scenes[currentScene]);
        }
        else
        {
            currentScene = 0;
            SceneManager.LoadScene(scenes[currentScene]);
        }
    }
}
